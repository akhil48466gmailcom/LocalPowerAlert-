package com.example.localpoweralert

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {
    private fun tv(text:String, size:Float=16f): TextView {
        return TextView(this).apply { this.text=text; textSize=size; setTextColor(Color.DKGRAY); setPadding(24,18,24,18) }
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val scroll = ScrollView(this)
        val box = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(20,20,20,30) }
        box.addView(tv("⚡ Local Power Alert", 28f))
        box.addView(tv("Zaheerabad • Sangareddy", 15f))
        box.addView(tv("🟢 POWER STATUS: ON", 22f).apply { setTextColor(Color.rgb(25,120,60)) })
        box.addView(tv("Next scheduled update: Check official utility notice"))
        box.addView(tv("━━━━━━━━━━━━━━━━━━━━", 12f))
        box.addView(tv("🔔 TODAY'S LOCAL ALERTS", 21f))
        box.addView(tv("🪔 Vinayaka Agaman\n📍 Local procession route\n🕐 Time: To be announced\n🚧 Road diversion: To be announced\n⚡ Power impact: Official confirmation required", 17f))
        box.addView(Button(this).apply { text="Notify me before an alert"; setOnClickListener { Toast.makeText(this@MainActivity,"Alerts enabled for this prototype",Toast.LENGTH_SHORT).show() } })
        box.addView(Button(this).apply { text="Report a local update"; setOnClickListener { Toast.makeText(this@MainActivity,"Reporting feature coming next",Toast.LENGTH_SHORT).show() } })
        box.addView(tv("OFFICIAL INFORMATION\nPower shutdown notices, restoration times and officer contacts should be verified from the electricity department before publishing.", 14f))
        scroll.addView(box); setContentView(scroll)
    }
}
